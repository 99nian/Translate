﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _SCREEN_CAPTURE
{
    public class ScreenCapture
    {
    }
}
