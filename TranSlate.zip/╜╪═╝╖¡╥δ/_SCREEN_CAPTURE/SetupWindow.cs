﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _SCREEN_CAPTURE
{
    public partial class SetupWindow : Form
    {
        public SetupWindow()
        {
            InitializeComponent();
            textBox_Account.Text = ConfigurationManager.AppSettings["AccountNumber"];
            textBox_Password.Text = ConfigurationManager.AppSettings["Password"];
            textBox1.Text = ConfigurationManager.AppSettings["ScreenshotTranslation"];
            textBox_somall.Text = ConfigurationManager.AppSettings["SmallHump"];
            textBox_ZHTOEN.Text = ConfigurationManager.AppSettings["EnglishToChinese"];
            textBox_big.Text = ConfigurationManager.AppSettings["BigHump"];
            textBox__.Text = ConfigurationManager.AppSettings["Underline"];
        }

        public delegate void DateDelegate(LayoutData data);
        //定义事件
        public event DateDelegate DateEvent;

        private void button1_Click(object sender, EventArgs e)
        {
            LayoutData layout = new LayoutData();
            layout.AccountNumber = textBox_Account.Text;
            layout.Password = textBox_Password.Text;
            layout.ScreenshotTranslation = textBox1.Text;
            layout.EnglishToChinese = textBox_ZHTOEN.Text;
            layout.SmallHump = textBox_somall.Text;
            layout.BigHump = textBox_big.Text;
            layout.Underline = textBox__.Text;

            Configuration cfa = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            cfa.AppSettings.Settings["AccountNumber"].Value = textBox_Account.Text;
            cfa.AppSettings.Settings["Password"].Value = textBox_Password.Text;
            cfa.AppSettings.Settings["ScreenshotTranslation"].Value = textBox1.Text;
            cfa.AppSettings.Settings["EnglishToChinese"].Value = textBox_ZHTOEN.Text;
            cfa.AppSettings.Settings["SmallHump"].Value = textBox_somall.Text;
            cfa.AppSettings.Settings["BigHump"].Value = textBox_big.Text;
            cfa.AppSettings.Settings["Underline"].Value = textBox__.Text;
            cfa.Save();
            if (DateEvent != null)
                DateEvent(layout);//引发事件
            this.Close();

        }
    }
    public class LayoutData
    {
        public string AccountNumber { get; set; }
        public string Password { get; set; }
        public string ScreenshotTranslation { get; set; }
        public string EnglishToChinese { get; set; }
        public string SmallHump { get; set; }
        public string BigHump { get; set; }
        public string Underline { get; set; }
    }



}
