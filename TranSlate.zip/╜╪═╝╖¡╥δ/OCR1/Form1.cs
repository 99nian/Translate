﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Web;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.IO;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Threading;
using DllTest;
using _SCREEN_CAPTURE;
using System.Configuration;
using System.Runtime.InteropServices;

namespace OCR1
{
    public partial class Form1 : Form
    {
        static string 账号 = "";
        static string 密码 = "";
        static Keys 截图识别 = Keys.Q;
        static Keys 英译汉 = Keys.Z;
        static Keys 小驼峰 = Keys.Q;
        static Keys 大驼峰 = Keys.W;
        static Keys 下划线 = Keys.E;
        public Form1()
        {
            InitializeComponent();
         
            //控件随窗体全屏显示
            int count = this.Controls.Count * 2 + 2;
            float[] factor = new float[count];
            int i = 0;
            factor[i++] = Size.Width;
            factor[i++] = Size.Height;
            foreach (Control ctrl in this.Controls)
            {
                factor[i++] = ctrl.Location.X / (float)Size.Width;
                factor[i++] = ctrl.Location.Y / (float)Size.Height;
                ctrl.Tag = ctrl.Size;//!!!
            }
            Tag = factor;

            账号 = ConfigurationManager.AppSettings["AccountNumber"];
            if (账号 == "")
            {
                SetupWindow setupWindow = new SetupWindow();
                setupWindow.Show();
                setupWindow.DateEvent += SetupWindow_DateEvent;
            }
            密码 = ConfigurationManager.AppSettings["Password"];

            char[] charArray1 = ConfigurationManager.AppSettings["ScreenshotTranslation"].ToCharArray();
            截图识别 = (Keys)charArray1[0];

            char[] charArray2 = ConfigurationManager.AppSettings["SmallHump"].ToCharArray();
            小驼峰 = (Keys)charArray2[0];

            char[] charArray3 = ConfigurationManager.AppSettings["BigHump"].ToCharArray();
            大驼峰 = (Keys)charArray3[0];

            char[] charArray4 = ConfigurationManager.AppSettings["Underline"].ToCharArray();
            下划线 = (Keys)charArray4[0];

            char[] charArray5 = ConfigurationManager.AppSettings["EnglishToChinese"].ToCharArray();
            英译汉 = (Keys)charArray5[0];

        }


        private void SetupWindow_DateEvent(LayoutData data)
        {
            账号 = data.AccountNumber;
            密码 = data.Password;

            char[] charArray1 = data.ScreenshotTranslation.ToCharArray();
            截图识别 = (Keys)charArray1[0];

            char[] charArray2 = data.SmallHump.ToCharArray();
            小驼峰 = (Keys)charArray2[0];

            char[] charArray3 = data.BigHump.ToCharArray();
            大驼峰 = (Keys)charArray3[0];

            char[] charArray4 = data.Underline.ToCharArray();
            下划线 = (Keys)charArray4[0];

            char[] charArray5 = data.EnglishToChinese.ToCharArray();
            英译汉 = (Keys)charArray5[0];

        }

        /// <summary>
        /// POST请求
        /// </summary>
        class POST
        {

            /// <summary>
            /// 指定Post地址使用Get 方式获取全部字符串
            /// </summary>
            /// <param name="url">请求后台地址</param>
            /// <param name="content">Post提交数据内容(utf-8编码的)</param>
            /// <returns></returns>
            public string Post(string url, string content)
            {
                string result = "";
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/x-www-form-urlencoded";

                #region 添加Post 参数
                byte[] data = Encoding.UTF8.GetBytes(content);
                req.ContentLength = data.Length;
                using (Stream reqStream = req.GetRequestStream())
                {
                    reqStream.Write(data, 0, data.Length);
                    reqStream.Close();
                }
                #endregion

                HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
                Stream stream = resp.GetResponseStream();
                //获取响应内容
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    result = reader.ReadToEnd();
                }
                return result;
            }


            //1测试有效（Web端）
            /// <summary>
            /// 指定Post地址使用Get 方式获取全部字符串
            /// </summary>
            /// <param name="url">请求后台地址</param>
            /// <returns></returns>
            public string Post(string url)
            {

                string result = String.Format("");
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
                Stream stream = resp.GetResponseStream();
                //获取内容
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    result = reader.ReadToEnd();
                }
                return result;
            }
        }
        /// <summary>
        /// 图片转OCR
        /// </summary>
        class PictureToOcr
        {
            public string url { get; set; }
            //端口
            public string port { get; set; }
            //操作类型
            public string opt { get; set; }
            //数据类型
            public string img_type { get; set; }
            //返回类型
            public string ret_type { get; set; }

            public string GetUrl()
            {
                return String.Format("http://{0}:{1}/{2}/{3}/{4}", this.url, this.port, this.opt, this.img_type, this.ret_type);
            }
        }
        /// <summary>
        /// 图片转Base64
        /// </summary>
        class PictureToBase64
        {
            public string ImageToBase64(string fileFullName)
            {
                try
                {
                    Bitmap bmp = new Bitmap(fileFullName);
                    MemoryStream ms = new MemoryStream();
                    bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    byte[] arr = new byte[ms.Length]; ms.Position = 0;
                    ms.Read(arr, 0, (int)ms.Length); ms.Close();
                    return Convert.ToBase64String(arr);
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
            public string BimpToBase64(Bitmap bmp)
            {
                try
                {
                    MemoryStream ms = new MemoryStream();
                    bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    byte[] arr = new byte[ms.Length];
                    ms.Position = 0;
                    ms.Read(arr, 0, (int)ms.Length);
                    ms.Close();
                    String strbaser64 = Convert.ToBase64String(arr);
                    return strbaser64;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ImgToBase64String 转换失败 Exception:" + ex.Message);
                    return "";
                }
            }
        }
        /// <summary>
        /// Json数据解析
        /// </summary>
        class JsonDate
        {
            public string status { get; set; }

            public string result { get; set; }

            public string msg { get; set; }
        }
        class BaiduJsonDate
        {
            public string from { get; set; }
            public string to { get; set; }
            public Result[] trans_result { get; set; }
        }
        class Result
        {
            public string src { get; set; }
            public string dst { get; set; }
        }
        /// <summary>
        /// 百度翻译接口
        /// </summary>
        class BaiduAPI
        {
            public string Translate(string q, string from, string to)
            {
                // 原文
                // string q = msg;
                // 源语言
                //string from = "en";
                // 目标语言
                //string to = "zh";
                // 改成您的APP ID
                string appId = 账号;
                Random rd = new Random();
                string salt = rd.Next(100000).ToString();
                // 改成您的密钥
                string secretKey = 密码;
                string sign = EncryptString(appId + q + salt + secretKey);
                string url = "http://api.fanyi.baidu.com/api/trans/vip/translate?";
                url += "q=" + HttpUtility.UrlEncode(q);
                url += "&from=" + from;
                url += "&to=" + to;
                url += "&appid=" + appId;
                url += "&salt=" + salt;
                url += "&sign=" + sign;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                request.ContentType = "text/html;charset=UTF-8";
                request.UserAgent = null;
                request.Timeout = 6000;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream myResponseStream = response.GetResponseStream();
                StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
                string retString = myStreamReader.ReadToEnd();
                myStreamReader.Close();
                myResponseStream.Close();
                return retString;
            }
            // 计算MD5值
            public static string EncryptString(string str)
            {
                MD5 md5 = MD5.Create();
                // 将字符串转换成字节数组
                byte[] byteOld = Encoding.UTF8.GetBytes(str);
                // 调用加密方法
                byte[] byteNew = md5.ComputeHash(byteOld);
                // 将加密结果转换为字符串
                StringBuilder sb = new StringBuilder();
                foreach (byte b in byteNew)
                {
                    // 将字节转换成16进制表示的字符串，
                    sb.Append(b.ToString("x2"));
                }
                // 返回加密的字符串
                return sb.ToString();
            }
        }

        /// <summary>
        /// 字符串大写前面加空格
        /// </summary>
        class StringToB
        {
            public static string UnPascalCase(string text)
            {
                if (string.IsNullOrWhiteSpace(text))
                    return "";
                var newText = new StringBuilder(text.Length * 2);
                newText.Append(text[0]);
                for (int i = 1; i < text.Length; i++)
                {
                    var currentUpper = char.IsUpper(text[i]);
                    var prevUpper = char.IsUpper(text[i - 1]);
                    var nextUpper = (text.Length > i + 1) ? char.IsUpper(text[i + 1]) || char.IsWhiteSpace(text[i + 1]) : prevUpper;
                    var spaceExists = char.IsWhiteSpace(text[i - 1]);
                    if (currentUpper && !spaceExists && (!nextUpper || !prevUpper))
                        newText.Append(' ');
                    newText.Append(text[i]);
                }
                return newText.ToString();
            }
        }

        class EnTOB
        {
            /// <summary>
            /// 字符串转大驼峰  AbAb
            /// </summary>
            /// <param name="str"></param>
            /// <returns></returns>
            public static string ToBigPascal(string str)
            {
                string[] split = str.Split(new char[] { '/', ' ', '_', '.', '\'' });
                split = split.Where(s => !string.IsNullOrEmpty(s)).ToArray();//清除空字符串
                string newStr = "";
                foreach (var item in split)
                {
                    char[] chars = item.ToCharArray();
                    chars[0] = char.ToUpper(chars[0]);
                    for (int i = 1; i < chars.Length; i++)
                    {
                        chars[i] = char.ToLower(chars[i]);
                    }
                    newStr += new string(chars);
                }
                return newStr;
            }
            /// <summary>
            /// 字符串转小驼峰
            /// </summary>
            /// <param name="str"></param>
            /// <returns></returns>
            public static string ToSomPascal(string str)
            {
                string[] split = str.Split(new char[] { '/', ' ', '_', '.', '\'' });
                split = split.Where(s => !string.IsNullOrEmpty(s)).ToArray();//清除空字符串
                string newStr = "";
                foreach (var item in split)
                {
                    char[] chars = item.ToCharArray();
                    //判断第一个元素
                    if (split.First() == item)
                    {
                        chars[0] = char.ToLower(chars[0]);
                    }
                    else
                    {
                        chars[0] = char.ToUpper(chars[0]);
                    }
                    for (int i = 1; i < chars.Length; i++)
                    {
                        chars[i] = char.ToLower(chars[i]);
                    }
                    newStr += new string(chars);
                }
                return newStr;
            }
            /// <summary>
            /// 变量名转_格式 Ai_Bi_C
            /// </summary>
            /// <param name="str"></param>
            /// <returns></returns>
            public static string To_Pascal(string str)
            {
                string[] split = str.Split(new char[] { '/', ' ', '_', '.', '\'' });
                split = split.Where(s => !string.IsNullOrEmpty(s)).ToArray();//清除空字符串
                string newStr = "";
                foreach (var item in split)
                {
                    char[] chars = item.ToCharArray();
                    chars[0] = char.ToUpper(chars[0]);
                    for (int i = 1; i < chars.Length; i++)
                    {
                        chars[i] = char.ToLower(chars[i]);
                    }
                    newStr += new string(chars);
                }
                newStr = StringToB.UnPascalCase(newStr);//调用加载空格
                newStr = newStr.Replace(" ", "_");
                return newStr;
            }
        }



        /// <summary>
        /// 全局快捷键
        /// </summary>
        class HotKey
        {
            //如果函数执行成功，返回值不为0。
            //如果函数执行失败，返回值为0。要得到扩展错误信息，调用GetLastError。
            [DllImport("user32.dll", SetLastError = true)]
            public static extern bool RegisterHotKey(
                            IntPtr hWnd,                //要定义热键的窗口的句柄
                int id,                     //定义热键ID（不能与其它ID重复）
                KeyModifiers fsModifiers,   //标识热键是否在按Alt、Ctrl、Shift、Windows等键时才会生效
                Keys vk                     //定义热键的内容
                );
            [DllImport("user32.dll", SetLastError = true)]
            public static extern bool UnregisterHotKey(
                IntPtr hWnd,                //要取消热键的窗口的句柄
                int id                      //要取消热键的ID
                );
            //定义了辅助键的名称（将数字转变为字符以便于记忆，也可去除此枚举而直接使用数值）
            [Flags()]
            public enum KeyModifiers
            {
                None = 0,
                Alt = 1,
                Ctrl = 2,
                Shift = 4,
                WindowsKey = 8
            }
        }

        #region 快捷键方法

        private void Form1_Activated(object sender, EventArgs e)
        {
            //注册热键Shift+S，Id号为100。HotKey.KeyModifiers.Shift也可以直接使用数字4来表示。
            HotKey.RegisterHotKey(Handle, 100, HotKey.KeyModifiers.Ctrl, 小驼峰);
            //注册热键Ctrl+B，Id号为101。HotKey.KeyModifiers.Ctrl也可以直接使用数字2来表示。
            HotKey.RegisterHotKey(Handle, 101, HotKey.KeyModifiers.Ctrl, 大驼峰);
            //注册热键Alt+D，Id号为102。HotKey.KeyModifiers.Alt也可以直接使用数字1来表示。
            HotKey.RegisterHotKey(Handle, 102, HotKey.KeyModifiers.Ctrl, 下划线);
            //注册热键Ctrl+B，Id号为101。HotKey.KeyModifiers.Ctrl也可以直接使用数字2来表示。
            HotKey.RegisterHotKey(Handle, 103, HotKey.KeyModifiers.Alt, 英译汉);
            //注册热键Alt+D，Id号为102。HotKey.KeyModifiers.Alt也可以直接使用数字1来表示。
            HotKey.RegisterHotKey(Handle, 104, HotKey.KeyModifiers.Alt, 截图识别);
        }
        //在FormA的Leave事件中注销热键。
        private void FrmSale_Leave(object sender, EventArgs e)
        {
            //注销Id号为100的热键设定
            HotKey.UnregisterHotKey(Handle, 100);
            //注销Id号为101的热键设定
            HotKey.UnregisterHotKey(Handle, 101);//

            HotKey.UnregisterHotKey(Handle, 102);

            HotKey.UnregisterHotKey(Handle, 103);//

            HotKey.UnregisterHotKey(Handle, 104);
        }

        // 重载FromA中的WndProc函数
        /// 
        /// 监视Windows消息
        /// 重载WndProc方法，用于实现热键响应
        /// 
        /// 
        protected override void WndProc(ref Message m)
        {

            const int WM_HOTKEY = 0x0312;
            //按快捷键 
            switch (m.Msg)
            {
                case WM_HOTKEY:
                    switch (m.WParam.ToInt32())
                    {
                        case 100:    //按下的是Ctrl+Q
                            mainLL("zh", "en", "small", true); //小驼峰转换
                            break;
                        case 101:    //按下的是Ctrl+B
                            mainLL("zh", "en", "big", true); //大驼峰转换
                            break;
                        case 102:    //按下的是Ctrl+E
                            mainLL("zh", "en", "_", true); //大驼峰转换 
                            break;
                        case 103:    //按下的是Ctrl+B
                            mainLL("en", "zh", "no", true);//英译汉
                            break;
                        case 104:    //按下的是Ctrl+E
                            FrmCapture frmC = new FrmCapture();
                            frmC.Show();
                            frmC.MyEvent += FrmC_MyEvent;
                            break;
                    }
                    break;
            }
            base.WndProc(ref m);
        }
        #endregion



        //主程序函数
        public void mainLL(string from, string to, string format, bool copy)
        {
            string str = "";
            //视觉翻译
            if (Base64 != "")
            {
                PictureToOcr pictureToOcr = new PictureToOcr();
                pictureToOcr.url = "123.56.235.156";
                pictureToOcr.port = "9898";
                pictureToOcr.opt = "ocr";
                pictureToOcr.img_type = "b64";
                pictureToOcr.ret_type = "json";
                string url = pictureToOcr.GetUrl();
                POST get = new POST();
                string g = get.Post(url, Base64);
                //解析JSON报文
                JsonDate jsondate = JsonConvert.DeserializeObject<JsonDate>(g);

                //textBox1.text=String.Format("状态:{0},文字:{1},错误:{2}", jsondate.status, jsondate.result, jsondate.msg);
                string ocrDate = jsondate.result;

                //寻找特殊字符 添加空格后翻译
                textBox1.Text = StringToB.UnPascalCase(ocrDate);
            }
            //字体翻译
            if (copy)
            {
                //SendKeys.Send("^c");//按下复制键

                if (Clipboard.ContainsText(TextDataFormat.Text))
                {
                    string clipboardText = Clipboard.GetText(TextDataFormat.Text);//复制剪切板里的数值
                    str = StringToB.UnPascalCase(clipboardText);
                }
            }
            else
            {
                if (textBox1.Text != "")
                {
                    str = StringToB.UnPascalCase(textBox1.Text);
                }

            }

            if (str != "")
            {
                textBox1.Text = str;
                //百度翻译
                BaiduAPI baidu = new BaiduAPI();
                BaiduJsonDate baiduJsonDate = JsonConvert.DeserializeObject<BaiduJsonDate>(baidu.Translate(str, from, to));
                if (baiduJsonDate.trans_result == null)
                {
                    return;
                }
                else if (from == "en")
                {
                    textBox2.Text = baiduJsonDate.trans_result[0].dst;
                }
                else
                {
                    string s = baiduJsonDate.trans_result[0].dst;
                    //程序员变量名书写
                    switch (format)
                    {
                        case "big":
                            s = EnTOB.ToBigPascal(s);
                            break;
                        case "small":
                            s = EnTOB.ToSomPascal(s);
                            break;
                        case "_":
                            s = EnTOB.To_Pascal(s);
                            break;
                    }
                    textBox2.Text = s;
                    Clipboard.SetText(s);//将数据复制到剪切板
                    SendKeys.Send("^v");//按下复制键
                    SendKeys.Flush();


                }
                //翻译完成清空
                Base64 = "";
            }
        }



        /// <summary>
        /// 按钮组合
        /// </summary>

        ///英译汉
        private void button1_Click(object sender, EventArgs e)
        {
            mainLL("en", "zh", "no", false);
        }
        /// <summary>
        /// 汉译英  转驼峰
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            mainLL("zh", "en", "no", false);
        }

        public static string Base64 = "";

        //截图
        private void button7_Click(object sender, EventArgs e)
        {
            //this.Enabled = false;
            //FrmCapture.ImgProcessBox = new ImageProcessBox();
            FrmCapture frmC = new FrmCapture();
            frmC.Show();

            frmC.MyEvent += FrmC_MyEvent;

            // frmC.FormClosed += FrmC_FormClosed;


            //frmC.m_bmpLayerCurrent
            //frmC.IsCaptureCursor = true;                //是否捕获鼠标
            //frmC.ImgProcessBoxIsShowInfo = true;        //是否绘制图像信息显示
            //frmC.ImgProcessBoxDotColor = Color.Yellow;  //操作框点的颜色
            //frmC.ImgProcessBoxLineColor = Color.Cyan;   //操作框边框的颜色
            //frmC.ImgProcessBoxMagnifySize = new System.Drawing.Size(15, 15);//信息的原始图像大小
            //frmC.ImgProcessBoxMagnifyTimes = 7;         //信息放大的倍数

        }


        private void FrmC_MyEvent(Bitmap bitmap, Form form)
        {
            try
            {
                Bitmap bitmap1 = bitmap;
                PictureToBase64 pictureToBase64 = new PictureToBase64();
                Base64 = pictureToBase64.BimpToBase64(bitmap1);
                form.Close();
                mainLL("en", "zh", "no", false);

            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
        }


        //选图
        private void button2_Click(object sender, EventArgs e)
        {

            OpenFileDialog openfile = new OpenFileDialog();

            if (openfile.ShowDialog() == DialogResult.OK && (openFileDialog1.FileName != "")) ;
            {
                //pictureBox1.ImageLocation = openfile.FileName;
                textBox1.Text = openfile.FileName;
                PictureToBase64 pictureToBase64 = new PictureToBase64();
                Func<string, string> pictToBase64 = new Func<string, string>(pictureToBase64.ImageToBase64);
                Base64 = pictToBase64(openfile.FileName);
            }

            openfile.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            mainLL("zh", "en", "small", false);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            mainLL("zh", "en", "big", false);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            mainLL("zh", "en", "_", false);
        }


        //托盘化
        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            this.Visible = true;//
            this.WindowState = FormWindowState.Normal;//窗口正常显示
            this.ShowInTaskbar = true;//在任务栏中显示该窗口

        }


        private void Form1_Resize(object sender, EventArgs e)
        {
            //控件随窗体全屏显示
            float[] scale = (float[])Tag;
            int i = 2;

            foreach (Control ctrl in this.Controls)
            {
                ctrl.Left = (int)(Size.Width * scale[i++]);
                ctrl.Top = (int)(Size.Height * scale[i++]);
                ctrl.Width = (int)(Size.Width / (float)scale[0] * ((Size)ctrl.Tag).Width);//!!!
                ctrl.Height = (int)(Size.Height / (float)scale[1] * ((Size)ctrl.Tag).Height);//!!!

                //每次使用的都是最初始的控件大小，保证准确无误。
            }



        }


        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }

        private void 配置APIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetupWindow setupWindow = new SetupWindow();
            setupWindow.Show();
            setupWindow.DateEvent += SetupWindow_DateEvent;
        }
        //关闭按钮
        private void uiSymbolButton1_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }
        //最小化按钮
        private void uiSymbolButton2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            if (this.WindowState == FormWindowState.Minimized)//当窗体设置值为最小化时
            {
                notifyIcon1.Visible = true;//该控件可见
                this.ShowInTaskbar = false;//在任务栏中显示该窗口
            }
            else
            {
                notifyIcon1.Visible = false;//否则该控件不可见
            }
        }
        //设置按钮
        private void uiSymbolButton3_Click(object sender, EventArgs e)
        {
            SetupWindow setupWindow = new SetupWindow();
            setupWindow.Show();
            setupWindow.DateEvent += SetupWindow_DateEvent;
        }


        //无边框窗口移动
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;
        //改变窗体大小
        public const int WMSZ_LEFT = 0xF001;
        public const int WMSZ_RIGHT = 0xF002;
        public const int WMSZ_TOP = 0xF003;
        public const int WMSZ_TOPLEFT = 0xF004;
        public const int WMSZ_TOPRIGHT = 0xF005;
        public const int WMSZ_BOTTOM = 0xF006;
        public const int WMSZ_BOTTOMLEFT = 0xF007;
        public const int WMSZ_BOTTOMRIGHT = 0xF008;

        private void uiNavBar1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }


        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, WMSZ_RIGHT, 0);
        }

        private void uiSymbolButton4_Click(object sender, EventArgs e)
        {
            
            if (this.TopMost)
            {
                this.TopMost = false;
                uiSymbolButton4.SymbolColor = Color.FromArgb(64, 128, 204);
            }
            else
            {
                this.TopMost = true;
                uiSymbolButton4.SymbolColor = Color.Yellow;

            }
        }

        private void uiSymbolButton5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void uiSymbolButton6_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBox2.Text);//将数据复制到剪切板
        }
    }
}
